package gui.helper;

public interface ValidatorInterface {
	public String validate(String s) throws IllegalStringException;
}
