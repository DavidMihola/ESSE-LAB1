package gui.helper;

public class IllegalStringException extends Exception {

}
